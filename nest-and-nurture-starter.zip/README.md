# Nest & Nurture — free starter app

## What this is
An installable Progressive Web App (PWA) starter for iPhone and Android. It includes a family dashboard, calendar, child profiles and milestones, meal planner, grocery list, household budget, checklists, and notes.

## Run it on your computer
You can open `index.html` directly to try most features. For install/offline features, serve it over HTTPS (or localhost).

## Free publishing option: GitHub Pages
1. Create or sign in to a free GitHub account.
2. Create a new **public** repository named `nest-and-nurture`.
3. Upload `index.html`, `manifest.json`, `sw.js`, and `icon.svg` from this folder.
4. In the repository, open **Settings → Pages**.
5. Under Build and deployment, choose **Deploy from a branch**, select `main` and `/ (root)`, then Save.
6. Wait for GitHub Pages to publish the site. Your app URL will look like `https://YOUR-USERNAME.github.io/nest-and-nurture/`.

## Add to a phone
- iPhone: open the published URL in Safari → Share → Add to Home Screen.
- Android: open the URL in Chrome → menu → Install app / Add to Home screen.

## Important first-version limitations
- Data is stored only in the browser/device using local storage. It does not sync between family members or devices.
- Clearing browser data can erase app data. Export/backup and accounts should be added before relying on it for important records.
- This is not a medical app, bank, or secure document vault.
- A PWA is not automatically a native App Store or Google Play listing.
- Hosting on GitHub Pages is free for public repositories under GitHub's current free offering; platform terms can change.

## Next development milestone
Add data export/import backup, then user accounts and cloud sync only after choosing a suitable free-tier backend and reviewing its current limits and privacy requirements.
